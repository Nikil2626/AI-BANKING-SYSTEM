const TOKEN = 'mock-token-123456';

const users = {
  alice: { id: 1, username: 'alice', password: 'password', accountNumber: 'ACC-1001', balance: 5420.75 },
  bob: { id: 2, username: 'bob', password: 'password', accountNumber: 'ACC-1002', balance: 1230.00 },
};

const accounts = {
  'ACC-1001': { accountNumber: 'ACC-1001', username: 'alice', balance: 5420.75 },
  'ACC-1002': { accountNumber: 'ACC-1002', username: 'bob', balance: 1230.00 },
};

const transactions = [
  { id: 1, accountNumber: 'ACC-1001', type: 'deposit', amount: 1000, date: '2026-10-28', description: 'Salary credit' },
  { id: 2, accountNumber: 'ACC-1001', type: 'withdrawal', amount: 120.5, date: '2026-10-29', description: 'ATM withdrawal' },
  { id: 3, accountNumber: 'ACC-1001', type: 'transfer', amount: 250, date: '2026-10-30', description: 'Transfer to ACC-1002' },
  { id: 4, accountNumber: 'ACC-1001', type: 'deposit', amount: 500, date: '2026-11-02', description: 'Freelance payout' },
  { id: 5, accountNumber: 'ACC-1001', type: 'withdrawal', amount: 80, date: '2026-11-05', description: 'Groceries' },
  { id: 6, accountNumber: 'ACC-1001', type: 'transfer', amount: 120, date: '2026-11-10', description: 'Utilities payment' },
  { id: 7, accountNumber: 'ACC-1001', type: 'deposit', amount: 2000, date: '2026-11-15', description: 'Bonus' },
  { id: 8, accountNumber: 'ACC-1001', type: 'withdrawal', amount: 300, date: '2026-11-18', description: 'Cash withdrawal' },
  { id: 9, accountNumber: 'ACC-1001', type: 'transfer', amount: 450, date: '2026-11-20', description: 'Rent payment' },
  { id: 10, accountNumber: 'ACC-1001', type: 'deposit', amount: 750, date: '2026-11-22', description: 'Tax refund' },
];

let nextTransactionId = transactions.length + 1;
let nextUserId = 3;
let currentUsername = 'alice';

function delay(ms = 300) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function paged(items, page, size) {
  const start = (page - 1) * size;
  return {
    content: items.slice(start, start + size),
    totalElements: items.length,
    totalPages: Math.ceil(items.length / size),
    page,
    size,
  };
}

function currentUser() {
  return users[currentUsername];
}

function reject(message, status) {
  const err = new Error(message);
  err.response = { status, data: { message } };
  return err;
}

export const mockApi = {
  async register({ username, password }) {
    await delay();
    if (users[username]) throw reject('User already exists', 400);
    const id = nextUserId++;
    const accountNumber = `ACC-${1000 + id}`;
    users[username] = { id, username, password, accountNumber, balance: 0 };
    accounts[accountNumber] = { accountNumber, username, balance: 0 };
    return { user: { username, accountNumber, balance: 0 } };
  },

  async login({ username, password }) {
    await delay();
    const user = users[username];
    if (!user || user.password !== password) throw reject('Invalid username or password', 401);
    currentUsername = username;
    return { token: TOKEN, user: { username, accountNumber: user.accountNumber, balance: user.balance } };
  },

  async me() {
    await delay();
    const user = currentUser();
    return { accountNumber: user.accountNumber, username: user.username, balance: user.balance };
  },

  async deposit({ amount }) {
    await delay();
    const user = currentUser();
    user.balance = Number((user.balance + amount).toFixed(2));
    accounts[user.accountNumber].balance = user.balance;
    transactions.unshift({
      id: nextTransactionId++,
      accountNumber: user.accountNumber,
      type: 'deposit',
      amount,
      date: new Date().toISOString().slice(0, 10),
      description: 'Cash deposit',
    });
    return { accountNumber: user.accountNumber, balance: user.balance };
  },

  async withdraw({ amount }) {
    await delay();
    const user = currentUser();
    if (amount > user.balance) throw reject('Insufficient funds', 400);
    user.balance = Number((user.balance - amount).toFixed(2));
    accounts[user.accountNumber].balance = user.balance;
    transactions.unshift({
      id: nextTransactionId++,
      accountNumber: user.accountNumber,
      type: 'withdrawal',
      amount,
      date: new Date().toISOString().slice(0, 10),
      description: 'Cash withdrawal',
    });
    return { accountNumber: user.accountNumber, balance: user.balance };
  },

  async transfer({ toAccountNumber, amount }) {
    await delay();
    const user = currentUser();
    if (amount > user.balance) throw reject('Insufficient funds', 400);
    user.balance = Number((user.balance - amount).toFixed(2));
    accounts[user.accountNumber].balance = user.balance;
    transactions.unshift({
      id: nextTransactionId++,
      accountNumber: user.accountNumber,
      type: 'transfer',
      amount,
      date: new Date().toISOString().slice(0, 10),
      description: `Transfer to ${toAccountNumber}`,
    });
    return { accountNumber: user.accountNumber, balance: user.balance };
  },

  async transactions({ page, size, type, from, to }) {
    await delay();
    let list = transactions.filter((t) => t.accountNumber === currentUser().accountNumber);
    if (type) list = list.filter((t) => t.type === type);
    if (from) list = list.filter((t) => t.date >= from);
    if (to) list = list.filter((t) => t.date <= to);
    list.sort((a, b) => new Date(b.date) - new Date(a.date));
    return paged(list, page, size);
  },

  async chat({ message }) {
    await delay(600);
    const lower = (message || '').toLowerCase();
    const user = currentUser();
    let reply;
    if (lower.includes('balance')) {
      reply = `Your current balance is $${user.balance.toFixed(2)}.`;
    } else if (lower.includes('transfer') || lower.includes('send money')) {
      reply = 'To transfer money, go to Dashboard, enter the recipient account number and amount, then confirm.';
    } else if (lower.includes('deposit')) {
      reply = 'Use the Deposit form on the Dashboard to add funds to your account.';
    } else if (lower.includes('withdraw')) {
      reply = 'Use the Withdraw form on the Dashboard to take out cash.';
    } else if (lower.includes('transaction') || lower.includes('history')) {
      reply = 'Visit the Transactions page to view your full history with filters by type and date.';
    } else if (lower.includes('insight') || lower.includes('spend')) {
      reply = 'Check the Insights page for your spending breakdown by category and AI summary.';
    } else if (lower.includes('hello') || lower.includes('hi ')) {
      reply = 'Hello! I am your AI Banking Assistant. Ask me about your balance, transactions, transfers, or insights.';
    } else {
      reply = "I'm not sure about that. Ask me about your balance, recent transactions, making a transfer, or your spending insights.";
    }
    return { reply };
  },

  async spending({ from, to }) {
    await delay();
    let list = transactions.filter((t) => t.accountNumber === currentUser().accountNumber);
    if (from) list = list.filter((t) => t.date >= from);
    if (to) list = list.filter((t) => t.date <= to);
    const categoryMap = {
      'Salary credit': 'Income',
      'Freelance payout': 'Income',
      Bonus: 'Income',
      'Tax refund': 'Income',
      'ATM withdrawal': 'Cash',
      'Cash withdrawal': 'Cash',
      Groceries: 'Groceries',
      'Utilities payment': 'Bills',
      'Rent payment': 'Rent',
    };
    const byCategory = {};
    let totalSpent = 0;
    list.forEach((t) => {
      const cat = t.type === 'deposit' ? 'Income' : (categoryMap[t.description] || 'Other');
      byCategory[cat] = (byCategory[cat] || 0) + t.amount;
      if (t.type !== 'deposit') totalSpent += t.amount;
    });
    const top = Object.entries(byCategory).sort((a, b) => b[1] - a[1])[0] || ['None', 0];
    const aiSummary = `Over the selected period you spent $${totalSpent.toFixed(2)} across ${
      Object.keys(byCategory).length
    } categories. Top category: ${top[0]} at $${top[1].toFixed(2)}.`;
    return { byCategory, totalSpent, topCategory: { category: top[0], amount: top[1] }, aiSummary };
  },
};
