import { useState, useRef, useEffect } from 'react';
import { chatApi } from '../api';

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const scrollRef = useRef(null);

  useEffect(() => {
    const panel = scrollRef.current;
    if (panel) panel.scrollTop = panel.scrollHeight;
  }, [messages]);

  async function sendMessage() {
    const text = (input || '').trim();
    if (!text) return;

    const userMsg = { role: 'user', text };
    setMessages((m) => [...m, userMsg]);
    setInput('');
    setError(null);
    setLoading(true);

    try {
      const { reply } = await chatApi.message({ message: text });
      setMessages((m) => [...m, { role: 'assistant', text: reply }]);
    } catch (err) {
      const msg = err.response?.data?.message || err.message || 'Failed to send message';
      setError(msg);
      setMessages((m) => [...m, { role: 'assistant', text: `Error: ${msg}` }]);
    } finally {
      setLoading(false);
    }
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter') sendMessage();
  }

  return (
    <div className="chat-widget">
      <button className="chat-toggle" onClick={() => setOpen(!open)} aria-label="Open AI assistant">
        <span className="chat-dot" /> Assistant
      </button>

      {open && (
        <div className="chat-panel">
          <div className="chat-header">
            AI Banking Assistant
            <button className="btn-close" onClick={() => setOpen(false)} aria-label="Close">×</button>
          </div>
          <div className="chat-body" ref={scrollRef}>
            {messages.length === 0 && (
              <div className="welcome">
                Ask me about your balance, transactions, transfers, or spending insights.
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} className={`message ${m.role}`}>
                {m.role === 'user' ? 'You:' : 'Assistant:'} {m.text}
              </div>
            ))}
            {error && <div className="message error">{error}</div>}
            {loading && <div className="message assistant">Typing…</div>}
          </div>
          <div className="chat-footer">
            <input
              className="chat-input"
              type="text"
              placeholder="Type a message..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              disabled={loading}
            />
            <button className="btn btn-sm" onClick={sendMessage} disabled={loading || !input.trim()}>
              Send
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
