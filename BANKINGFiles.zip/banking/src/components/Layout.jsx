import { Outlet, Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import ChatWidget from '../components/ChatWidget';

export default function Layout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="layout">
      <nav className="navbar">
        <div className="brand">AI <span>Banking</span></div>
        <div className="nav-links">
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/transactions">Transactions</Link>
          <Link to="/insights">Insights</Link>
        </div>
        <div className="nav-account">
          {user ? (
            <span className="account">
              {user.username} &middot; {user.accountNumber}
            </span>
          ) : null}
          <button className="btn-logout" onClick={() => { logout(); navigate('/login'); }}>
            Sign out
          </button>
        </div>
      </nav>
      <main className="page"><Outlet /></main>
      <ChatWidget />
    </div>
  );
}
