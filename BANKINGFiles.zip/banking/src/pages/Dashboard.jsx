import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { accountApi } from '../api';

export default function Dashboard() {
  const { user } = useAuth();
  const [account, setAccount] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [form, setForm] = useState({ amount: '', toAccountNumber: '' });
  const [formError, setFormError] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitMessage, setSubmitMessage] = useState(null);

  useEffect(() => {
    loadAccount();
  }, []);

  async function loadAccount() {
    setLoading(true);
    setError(null);
    try {
      const data = await accountApi.me();
      setAccount(data);
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Failed to load account');
    } finally {
      setLoading(false);
    }
  }

  async function handleSubmit(e, action) {
    e.preventDefault();
    setFormError(null);
    setSubmitMessage(null);
    setSubmitting(true);

    const amount = Number(form.amount);
    if (!form.amount || Number.isNaN(amount) || amount <= 0) {
      setFormError('Amount must be greater than 0');
      setSubmitting(false);
      return;
    }

    try {
      if (action === 'deposit') {
        await accountApi.deposit({ amount });
      } else if (action === 'withdraw') {
        await accountApi.withdraw({ amount });
      } else if (action === 'transfer') {
        if (!form.toAccountNumber) {
          setFormError('Recipient account number is required');
          setSubmitting(false);
          return;
        }
        await accountApi.transfer({ toAccountNumber: form.toAccountNumber, amount });
      }
      setSubmitMessage(`${action} completed`);
      await loadAccount();
    } catch (err) {
      setFormError(err.response?.data?.message || err.message || 'Action failed');
    } finally {
      setSubmitting(false);
    }
  }

  if (loading) {
    return (
      <div className="page">
        <div className="state">
          <div className="spinner" />
          <h3>Loading account…</h3>
        </div>
      </div>
    );
  }

  if (error || !account) {
    return (
      <div className="page">
        <div className="state">
          <h3>Unable to load account</h3>
          <p>{error || 'No account data available'}</p>
          <button className="btn btn-primary" onClick={loadAccount}>Retry</button>
        </div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="card-header">
        <div>
          <h2>Dashboard</h2>
          <p className="subtitle">Welcome back, {user.username}</p>
        </div>
        <button className="btn btn-outline" onClick={loadAccount}>Refresh</button>
      </div>

      <div className="account-row">
        <div className="account-card card">
          <div className="label">Account number</div>
          <div className="value">${account.accountNumber}</div>
          <div className="number">{account.accountNumber}</div>
        </div>
        <div className="account-card card">
          <div className="label">Available balance</div>
          <div className="value">${account.balance.toFixed(2)}</div>
          <div className="number">USD</div>
        </div>
      </div>

      <div className="actions-grid">
        <form onSubmit={(e) => handleSubmit(e, 'deposit')} className="card">
          <div className="card-header">
            <h3>Deposit</h3>
          </div>
          <div className="field">
            <label>Amount (USD)</label>
            <input
              name="amount"
              type="number"
              step="0.01"
              min="0"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
              className={formError ? 'error' : ''}
              required
            />
            {formError && <span className="field-error">{formError}</span>}
          </div>
          <button className="btn btn-primary" type="submit" disabled={submitting}>
            {submitting ? 'Processing…' : 'Deposit'}
          </button>
          {submitMessage && <p className="field-success">{submitMessage}</p>}
        </form>

        <form onSubmit={(e) => handleSubmit(e, 'withdraw')} className="card">
          <div className="card-header">
            <h3>Withdraw</h3>
          </div>
          <div className="field">
            <label>Amount (USD)</label>
            <input
              name="amount"
              type="number"
              step="0.01"
              min="0"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
              className={formError ? 'error' : ''}
              required
            />
            {formError && <span className="field-error">{formError}</span>}
          </div>
          <button className="btn btn-primary" type="submit" disabled={submitting}>
            {submitting ? 'Processing…' : 'Withdraw'}
          </button>
          {submitMessage && <p className="field-success">{submitMessage}</p>}
        </form>

        <form onSubmit={(e) => handleSubmit(e, 'transfer')} className="card">
          <div className="card-header">
            <h3>Transfer</h3>
          </div>
          <div className="field">
            <label>To account number</label>
            <input
              name="toAccountNumber"
              type="text"
              value={form.toAccountNumber}
              onChange={(e) => setForm({ ...form, toAccountNumber: e.target.value })}
              required
            />
          </div>
          <div className="field">
            <label>Amount (USD)</label>
            <input
              name="amount"
              type="number"
              step="0.01"
              min="0"
              value={form.amount}
              onChange={(e) => setForm({ ...form, amount: e.target.value })}
              className={formError ? 'error' : ''}
              required
            />
            {formError && <span className="field-error">{formError}</span>}
          </div>
          <button className="btn btn-primary" type="submit" disabled={submitting}>
            {submitting ? 'Processing…' : 'Transfer'}
          </button>
          {submitMessage && <p className="field-error" style={{ color: '#166534', marginTop: 8 }}>{submitMessage}</p>}
        </form>
      </div>
    </div>
  );
}
