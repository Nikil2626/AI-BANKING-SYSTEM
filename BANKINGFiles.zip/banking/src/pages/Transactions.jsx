import { useState, useEffect, useCallback } from 'react';
import { transactionApi } from '../api';

const PAGE_SIZE = 10;

export default function Transactions() {
  const [page, setPage] = useState(1);
  const [typeFilter, setTypeFilter] = useState('');
  const [fromFilter, setFromFilter] = useState('');
  const [toFilter, setToFilter] = useState('');

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await transactionApi.list({
        page,
        size: PAGE_SIZE,
        type: typeFilter || undefined,
        from: fromFilter || undefined,
        to: toFilter || undefined,
      });
      setData(res);
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Failed to load transactions');
    } finally {
      setLoading(false);
    }
  }, [page, typeFilter, fromFilter, toFilter]);

  useEffect(() => {
    load();
  }, [load]);

  function goPage(delta) {
    setPage((p) => Math.max(1, Math.min(p + delta, data ? data.totalPages : 1)));
  }

  const rows = data ? data.content : [];
  const totalPages = data ? data.totalPages : 0;

  return (
    <div className="page">
      <h2>Transactions</h2>
      <div className="table-controls">
        <label>Type</label>
        <select value={typeFilter} onChange={(e) => { setTypeFilter(e.target.value); setPage(1); }}>
          <option value="">All</option>
          <option value="deposit">Deposit</option>
          <option value="withdrawal">Withdrawal</option>
          <option value="transfer">Transfer</option>
        </select>
        <label>From</label>
        <input type="date" value={fromFilter} onChange={(e) => { setFromFilter(e.target.value); setPage(1); }} />
        <label>To</label>
        <input type="date" value={toFilter} onChange={(e) => { setToFilter(e.target.value); setPage(1); }} />
      </div>

      {loading && (
        <div className="state">
          <div className="spinner" />
          <h3>Loading transactions…</h3>
        </div>
      )}

      {error && (
        <div className="state">
          <h3>Unable to load transactions</h3>
          <p>{error}</p>
          <button className="btn btn-primary" onClick={load}>Retry</button>
        </div>
      )}

      {!loading && !error && rows.length === 0 && (
        <div className="state">
          <h3>No transactions found</h3>
          <p>Adjust the filters or check back later.</p>
        </div>
      )}

      {!loading && !error && rows.length > 0 && (
        <>
          <table className="table">
            <thead>
              <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Amount</th>
                <th>Description</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((t) => (
                <tr key={t.id}>
                  <td>{t.date}</td>
                  <td>
                    <span className={`type-badge type-${t.type}`}>{t.type}</span>
                  </td>
                  <td className="amount">
                    {t.type === 'deposit' ? '+' : '-'}${t.amount.toFixed(2)}
                  </td>
                  <td>{t.description}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="pagination">
            <span>Page {page} of {totalPages}</span>
            <div>
              <button className="btn btn-outline btn-sm" onClick={() => goPage(-1)} disabled={page === 1}>
                Prev
              </button>
              <button className="btn btn-outline btn-sm" onClick={() => goPage(1)} disabled={page >= totalPages}>
                Next
              </button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
