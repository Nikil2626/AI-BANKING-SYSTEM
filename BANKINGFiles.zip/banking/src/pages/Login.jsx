import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useState } from 'react';

function validateEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(location.state?.message || '');
  const [fieldErrors, setFieldErrors] = useState({});

  function clearError() {
    setError('');
  }

  function validate() {
    const errs = {};
    if (!username.trim()) errs.username = 'Username is required';
    else if (!validateEmail(username)) errs.username = 'Enter a valid email address';
    if (!password) errs.password = 'Password is required';
    else if (password.length < 8) errs.password = 'Password must be at least 8 characters';
    setFieldErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    clearError();
    if (!validate()) return;
    setLoading(true);
    try {
      await login({ username, password });
      navigate('/dashboard');
    } catch (err) {
      setError(err?.response?.data?.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="page">
      <div className="auth-card">
        <h2>Sign in</h2>
        {error && <div className="alert" role="alert">{error}</div>}
        <form onSubmit={handleSubmit} className="auth-form">
          <div className="field">
            <label>Username</label>
            <input
              name="username"
              type="email"
              value={username}
              onChange={(e) => { setUsername(e.target.value); clearError(); setFieldErrors((f) => ({ ...f, username: undefined })); }}
              required
              placeholder="you@example.com"
            />
            {fieldErrors.username && <span className="field-error">{fieldErrors.username}</span>}
          </div>
          <div className="field">
            <label>Password</label>
            <input
              name="password"
              type="password"
              value={password}
              onChange={(e) => { setPassword(e.target.value); clearError(); setFieldErrors((f) => ({ ...f, password: undefined })); }}
              required
              placeholder="password"
            />
            {fieldErrors.password && <span className="field-error">{fieldErrors.password}</span>}
          </div>
          <button className="btn btn-primary" type="submit" disabled={loading}>
            {loading ? 'Signing in...' : 'Sign in'}
          </button>
        </form>
        <p className="hint">Mock credentials: use a registered email / password</p>
        <p className="hint">Don't have an account? <Link to="/register">Register</Link></p>
      </div>
    </div>
  );
}
