import { useState, useEffect, useCallback } from 'react';
import { insightsApi } from '../api';

export default function Insights() {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await insightsApi.spending({ from: from || undefined, to: to || undefined });
      setData(res);
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'Failed to load insights');
    } finally {
      setLoading(false);
    }
  }, [from, to]);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="page">
      <h2>Insights</h2>
      <div className="range-picker">
        <label>From</label>
        <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        <label>To</label>
        <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
      </div>

      {loading && (
        <div className="state">
          <div className="spinner" />
          <h3>Loading insights…</h3>
        </div>
      )}

      {error && (
        <div className="state">
          <h3>Unable to load insights</h3>
          <p>{error}</p>
          <button className="btn btn-primary" onClick={load}>Retry</button>
        </div>
      )}

      {!loading && !error && data && (
        <>
          <div className="insight-grid">
            <div className="insight-card card">
              <div className="label">Total spent</div>
              <div className="value">${data.totalSpent?.toFixed(2) ?? 0}</div>
            </div>
            <div className="insight-card card">
              <div className="label">Categories</div>
              <div className="value">{Object.keys(data.byCategory ?? {}).length}</div>
            </div>
            <div className="insight-card card">
              <div className="label">Top category</div>
              <div className="value">{data.topCategory?.category ?? '—'}</div>
            </div>
            <div className="insight-card card">
              <div className="label">Top category spend</div>
              <div className="value">${data.topCategory?.amount?.toFixed(2) ?? 0}</div>
            </div>
          </div>

          <div className="card">
            <div className="card-header">
              <h3>Spend per category</h3>
            </div>
            <div className="category-list">
              {Object.entries(data.byCategory ?? {}).map(([category, amount]) => (
                <div className="category-row" key={category}>
                  <span className="name">{category}</span>
                  <span className="amount">${amount.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="ai-summary">
            <div className="title">AI summary</div>
            <div className="body">{data.aiSummary ?? 'No summary available.'}</div>
          </div>
        </>
      )}

      {!loading && !error && !data && (
        <div className="state">
          <h3>No insights available</h3>
          <p>Select a date range to view your spending breakdown.</p>
        </div>
      )}
    </div>
  );
}
