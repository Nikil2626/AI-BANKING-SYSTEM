import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useState } from 'react';

function validateEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState({});

  function clearError() {
    setError('');
  }

  function validate() {
    const errs = {};
    if (!username.trim()) errs.username = 'Email is required';
    else if (!validateEmail(username)) errs.username = 'Enter a valid email address';
    if (!password) errs.password = 'Password is required';
    else if (password.length < 8) errs.password = 'Password must be at least 8 characters';
    if (!confirmPassword) errs.confirmPassword = 'Confirm password is required';
    else if (confirmPassword !== password) errs.confirmPassword = 'Passwords do not match';
    setFieldErrors(errs);
    return Object.keys(errs).length === 0;
  }

  async function handleSubmit(e) {
    e.preventDefault();
    clearError();
    if (!validate()) return;
    setLoading(true);
    try {
      await register({ username, password });
      navigate('/login', { state: { message: 'Account created. Please log in.' } });
    } catch (err) {
      setError(err?.response?.data?.message || 'Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="page">
      <div className="auth-card">
        <h2>Create account</h2>
        {error && <div className="alert" role="alert">{error}</div>}
        <form onSubmit={handleSubmit} className="auth-form">
          <div className="field">
            <label>Email</label>
            <input
              name="username"
              type="email"
              value={username}
              onChange={(e) => { setUsername(e.target.value); clearError(); setFieldErrors((f) => ({ ...f, username: undefined })); }}
              required
              placeholder="you@example.com"
            />
            {fieldErrors.username && <span className="field-error">{fieldErrors.username}</span>}
          </div>
          <div className="field">
            <label>Password</label>
            <input
              name="password"
              type="password"
              value={password}
              onChange={(e) => { setPassword(e.target.value); clearError(); setFieldErrors((f) => ({ ...f, password: undefined })); }}
              required
              minLength="8"
              placeholder="At least 8 characters"
            />
            {fieldErrors.password && <span className="field-error">{fieldErrors.password}</span>}
          </div>
          <div className="field">
            <label>Confirm password</label>
            <input
              name="confirmPassword"
              type="password"
              value={confirmPassword}
              onChange={(e) => { setConfirmPassword(e.target.value); clearError(); setFieldErrors((f) => ({ ...f, confirmPassword: undefined })); }}
              required
              minLength="8"
            />
            {fieldErrors.confirmPassword && <span className="field-error">{fieldErrors.confirmPassword}</span>}
          </div>
          <button className="btn btn-primary" type="submit" disabled={loading}>
            {loading ? 'Creating account...' : 'Create account'}
          </button>
        </form>
        <p className="hint">Already have an account? <Link to="/login">Sign in</Link></p>
      </div>
    </div>
  );
}
